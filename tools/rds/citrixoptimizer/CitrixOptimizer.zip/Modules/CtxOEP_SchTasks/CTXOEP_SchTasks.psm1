﻿# In order to support both Windows 7 and Windows 10, Get-ScheduledTask cannot be used. Original code was using schtasks, but since it's language specific, it had to be replaced with COM object Schedule.Service. 
$CTXOESchTasks_COMSchedule = New-Object –ComObject ("Schedule.Service")
$CTXOESchTasks_COMSchedule.Connect("localhost")

# Function to return all subfolders for scheduled tasks
Function Get-CTXOESchTasksSubfolders ($Folder) {
    [Array]$m_Subfolders = @()
    
    If ($Folder.Path -eq "\") {$m_Subfolders += $Folder}
    
    ForEach ($m_Folder in  $Folder.GetFolders(1)) {
        $m_Subfolders += $m_Folder;
        ForEach ($m_Subfolder in $(Get-CTXOESchTasksSubfolders -Folder $m_Folder)) {
            $m_Subfolders += $m_Subfolder;
        }
    }
    Return $m_Subfolders;
}

# function to return all scheduled tasks
Function Get-CTXOESchTasksTasks () {
    [Array]$m_Tasks = @()
    ForEach ($m_Subfolder in Get-CTXOESchTasksSubfolders -Folder $CTXOESchTasks_COMSchedule.GetFolder("\")) {
        $m_Tasks += $m_Subfolder.GetTasks(1);
    }
    Return $m_Tasks;
}

# Generate cache of all scheduled tasks
$CTXOESchTasks_Cache = Get-CTXOESchTasksTasks;
$CTXOESchTasks_IsCacheValid = $true;

# Check if leading and trailing "\" are available, if not append and return modified string
Function Test-CTXOESchTasksBackslashes ([string]$Path) {
    If ($Path -notlike "\*") {$Path = "\$Path"}

    If ($Path -notlike "*\") {$Path = "$Path\"}

    Return $Path
}

# Check if scheduled task exists
Function Test-CTXOESchTasksExist ([String]$Path) {
    Return $($CTXOESchTasks_Cache | Where-Object {$_.Path -eq "$Path"}) -is [Object]
}

# Check if scheduled task is enabled or disabled. Return $False for disabled, $True for enabled.
Function Test-CTXOESchTasksState ([String]$Path) {
    If ($CTXOESchTasks_IsCacheValid -eq $false) {$CTXOESchTasks_Cache = Get-CTXOESchTasksTasks};    
    Return [Boolean]$($CTXOESchTasks_Cache | Where-Object {$_.Path -eq $Path} | Select-Object -ExpandProperty Enabled)
}

Function Invoke-CTXOESchTasksExecuteInternal ([Xml.XmlElement]$Params, [Boolean]$RollbackSupported = $False) {


    [String]$m_Name = $Params.Name
    [String]$m_Path = Test-CTXOESchTasksBackslashes -Path $Params.Path
    [String]$m_State = $Params.Value
    [String]$m_FullPath = "$m_Path$m_Name"

    If ($m_State -ne "Disabled" -and $m_State -ne "Enabled") {Throw "Requested state is $m_State, which is not disabled or enabled"}

    [Boolean]$m_Exists = Test-CTXOESchTasksExist -Path $m_FullPath

    # If scheduled task does not exist, return $True if goal was to disable it, otherwise return $False
    If ($m_Exists -eq $False) {
        $Global:CTXOE_Result = $m_State -eq "Disabled"
        $Global:CTXOE_Details = "Scheduled task does not exist"
        Return
    }

    [Boolean]$m_CurrentState = Test-CTXOESchTasksState -Path $m_FullPath
    [Boolean]$m_DesiredState = $m_State -ne "Disabled"

    If ($m_DesiredState -eq $m_CurrentState) {
        $Global:CTXOE_Result = $True
        $Global:CTXOE_Details = "Scheduled Task already $($m_State)"
        Return
    } Else {

        $CTXOESchTasks_IsCacheValid = $false;
        [String]$m_RollbackState = ""

        If ($m_State -eq "Disabled") {
            schtasks /change /tn "$m_FullPath" /disable | Out-Null
            $CTXOESchTasks_IsCacheValid = $False;
            $m_RollbackState = "Enabled";
        } Else {
            schtasks /change /tn "$m_FullPath" /enable | Out-Null
            $CTXOESchTasks_IsCacheValid = $False;
            $m_RollbackState = "Disabled"
        }

        [Boolean]$m_CurrentState = Test-CTXOESchTasksState -Path $m_FullPath
    
        If ($m_DesiredState -eq $m_CurrentState) {
            $Global:CTXOE_Result = $True
            $Global:CTXOE_Details = "Scheduled Task has been $($m_State)"

            # System has been changed. Report it and generate a rollback element.
            $Global:CTXOE_SystemChanged = $true;
            If ($RollbackSupported) {
                [Xml.XmlDocument]$m_RollbackElement = CTXOE\ConvertTo-CTXOERollbackElement -Element $Params
                $m_RollbackElement.rollbackparams.value = $m_RollbackState
                $Global:CTXOE_ChangeRollbackParams = $m_RollbackElement
            }

            Return
        } Else {
            $Global:CTXOE_Result = $False
            $Global:CTXOE_Details = "Failed to set $($m_Name) to $($m_State) state"
            Return
        }
    }
    Return
}

Function Invoke-CTXOESchTasksAnalyze ([Xml.XmlElement]$Params) {

    [String]$m_Name = $Params.Name
    [String]$m_Path = Test-CTXOESchTasksBackslashes -Path $Params.Path
    [String]$m_State = $Params.Value
    [String]$m_FullPath = "$m_Path$m_Name"

    # If scheduled task does not exist, return $True if goal was to disable it, otherwise return $False
    If ($(Test-CTXOESchTasksExist -Path $m_FullPath) -eq $False) {
        $Global:CTXOE_Result = $m_State -eq "Disabled"
        $Global:CTXOE_Details = "Scheduled task does not exist"
        Return
    }

    [Boolean]$m_CurrentState = Test-CTXOESchTasksState -Path $m_FullPath

    If ($m_State -eq "Disabled" -and $m_CurrentState -eq $False) {
        $Global:CTXOE_Result = $True
        $Global:CTXOE_Details = "Scheduled Task is disabled"
    } ElseIf ($m_State -ne "Disabled" -and $m_CurrentState -ne $False) {
        $Global:CTXOE_Result = $True
        $Global:CTXOE_Details = "Scheduled Task is enabled"
    } Else {
        $Global:CTXOE_Result = $False
        $Global:CTXOE_Details = "Scheduled Task is not in $($m_State) state"
    }

    Return
}

Function Invoke-CTXOESchTasksExecute ([Xml.XmlElement]$Params) {
    Invoke-CTXOESchTasksExecuteInternal -Params $Params -RollbackSupported $true
}

Function Invoke-CTXOESchTasksRollback ([Xml.XmlElement]$Params) {
    Invoke-CTXOESchTasksExecuteInternal -Params $Params -RollbackSupported $false
}
# SIG # Begin signature block
# MIIbAAYJKoZIhvcNAQcCoIIa8TCCGu0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUHNN5B/AxBq4HvKnf6zPh2U9Y
# 8sigghT0MIIFJDCCBAygAwIBAgIQCpJdJFWANibhh6AFcJolkDANBgkqhkiG9w0B
# AQsFADByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFz
# c3VyZWQgSUQgVGltZXN0YW1waW5nIENBMB4XDTE4MDgwMTAwMDAwMFoXDTIzMDkw
# MTAwMDAwMFowYDELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFENpdHJpeCBTeXN0ZW1z
# LCBJbmMuMQ0wCwYDVQQLEwRHTElTMSMwIQYDVQQDExpDaXRyaXggVGltZXN0YW1w
# IFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANjWtJ4e
# cpVfB34YnxfYNvb1Rp2JbBu5/G9Boe8aEBQc2zidW82ousZrXj2QD2qUA1Ee8noo
# t1KGcQdY0WzzbSIU7KHePB5KaESWjtHVJ3BW6W9q+U24m2dPD/oaNxGx6DtD7M0N
# lMBIRZKo7aNIsRIlHkg7wnNQzqi0jTkzBO7S34holaqhfuQgqkgKqGmcoSIXVqNm
# EFaU+5kpYFqpMo6x1sSAgfgNEcIgGjnj8xzdU1rnh6iNYMxOt8guMWk2z+KKNbux
# H6YLAA9VBYW417Zf153/5L4ejuxxUhCp03JkoUIWjSRjz3m24HD9K8NSgJ0AdDpN
# E8ZPmIJCMFi9FYcCAwEAAaOCAcYwggHCMB8GA1UdIwQYMBaAFPS24SAd/imu0uRh
# pbKiJbLIFzVuMB0GA1UdDgQWBBS1Y37AhXUHPaYuvS/SUsWFFisSbTAMBgNVHRMB
# Af8EAjAAMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDBP
# BgNVHSAESDBGMDcGCWCGSAGG/WwHATAqMCgGCCsGAQUFBwIBFhxodHRwczovL3d3
# dy5kaWdpY2VydC5jb20vQ1BTMAsGCWCGSAGG/WwDFTBxBgNVHR8EajBoMDKgMKAu
# hixodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVkLXRzLmNybDAy
# oDCgLoYsaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC10cy5j
# cmwwgYUGCCsGAQUFBwEBBHkwdzAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tME8GCCsGAQUFBzAChkNodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRTSEEyQXNzdXJlZElEVGltZXN0YW1waW5nQ0EuY3J0MA0GCSqG
# SIb3DQEBCwUAA4IBAQBrQ4tHgdu37madmYML6Ikfb8bNWoritioGcrlVfsMEGdLN
# LAsPYqrMo9mZmNzKTE7UVzGVdwb+Cfz9IRfD6hmK6hhEuom+XNzC8LGQ3o7U2ede
# YF/xuIcFZAwmQnXOoVl4yDWKrfyalOIO9wpQ6bDV7f0CPa8j3Qj2eNJ2u2qKnRE+
# x5Iz8j5lsjQeefIriGVHd27R93ai0li9WZMT9KKOAk06R0Z0qyG70jXhoUp4Or5c
# lv5mmVJgmxr1hMjVg7v95WGY50p2+cfhqLlViu2cu0LCg31IUb0lbTYNbgY1eca2
# cr8F0ppVnrt55YVfb1M80huj9DeYYjeFSKkcN+6xMIIFMDCCBBigAwIBAgIQBAkY
# G1/Vu2Z1U0O1b5VQCDANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMG
# A1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQw
# IgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMTMxMDIyMTIw
# MDAwWhcNMjgxMDIyMTIwMDAwWjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhE
# aWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ29kZSBTaWduaW5nIENBMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+NOzHH8OEa9ndwfTCzFJGc/Q+0WZsTrb
# RPV/5aid2zLXcep2nQUut4/6kkPApfmJ1DcZ17aq8JyGpdglrA55KDp+6dFn08b7
# KSfH03sjlOSRI5aQd4L5oYQjZhJUM1B0sSgmuyRpwsJS8hRniolF1C2ho+mILCCV
# rhxKhwjfDPXiTWAYvqrEsq5wMWYzcT6scKKrzn/pfMuSoeU7MRzP6vIK5Fe7SrXp
# dOYr/mzLfnQ5Ng2Q7+S1TqSp6moKq4TzrGdOtcT3jNEgJSPrCGQ+UpbB8g8S9MWO
# D8Gi6CxR93O8vYWxYoNzQYIH5DiLanMg0A9kczyen6Yzqf0Z3yWT0QIDAQABo4IB
# zTCCAckwEgYDVR0TAQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0l
# BAwwCgYIKwYBBQUHAwMweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRw
# Oi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRz
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwgYEGA1Ud
# HwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFz
# c3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwTwYDVR0gBEgwRjA4BgpghkgB
# hv1sAAIEMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9D
# UFMwCgYIYIZIAYb9bAMwHQYDVR0OBBYEFFrEuXsqCqOl6nEDwGD5LfZldQ5YMB8G
# A1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMA0GCSqGSIb3DQEBCwUAA4IB
# AQA+7A1aJLPzItEVyCx8JSl2qB1dHC06GsTvMGHXfgtg/cM9D8Svi/3vKt8gVTew
# 4fbRknUPUbRupY5a4l4kgU4QpO4/cY5jDhNLrddfRHnzNhQGivecRk5c/5CxGwcO
# kRX7uq+1UcKNJK4kxscnKqEpKBo6cSgCPC6Ro8AlEeKcFEehemhor5unXCBc2XGx
# DI+7qPjFEmifz0DLQESlE/DmZAwlCEIysjaKJAL+L3J+HNdJRZboWR3p+nRka7Lr
# ZkPas7CM1ekN3fYBIM6ZMWM9CBoYs4GbT8aTEAb8B4H6i9r5gkn3Ym6hU/oSlBiF
# LpKR6mhsRDKyZqHnGKSaZFHvMIIFMTCCBBmgAwIBAgIQCqEl1tYyG35B5AXaNpfC
# FTANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNl
# cnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdp
# Q2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMTYwMTA3MTIwMDAwWhcNMzEwMTA3
# MTIwMDAwWjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkw
# FwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEy
# IEFzc3VyZWQgSUQgVGltZXN0YW1waW5nIENBMIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEAvdAy7kvNj3/dqbqCmcU5VChXtiNKxA4HRTNREH3Q+X1NaH7n
# tqD0jbOI5Je/YyGQmL8TvFfTw+F+CNZqFAA49y4eO+7MpvYyWf5fZT/gm+vjRkcG
# GlV+Cyd+wKL1oODeIj8O/36V+/OjuiI+GKwR5PCZA207hXwJ0+5dyJoLVOOoCXFr
# 4M8iEA91z3FyTgqt30A6XLdR4aF5FMZNJCMwXbzsPGBqrC8HzP3w6kfZiFBe/WZu
# VmEnKYmEUeaC50ZQ/ZQqLKfkdT66mA+Ef58xFNat1fJky3seBdCEGXIX8RcG7z3N
# 1k3vBkL9olMqT4UdxB08r8/arBD13ays6Vb/kwIDAQABo4IBzjCCAcowHQYDVR0O
# BBYEFPS24SAd/imu0uRhpbKiJbLIFzVuMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1R
# i6enIZ3zbcgPMBIGA1UdEwEB/wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMIMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MIGB
# BgNVHR8EejB4MDqgOKA2hjRodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNl
# cnRBc3N1cmVkSURSb290Q0EuY3JsMDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMFAGA1UdIARJMEcwOAYK
# YIZIAYb9bAACBDAqMCgGCCsGAQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5j
# b20vQ1BTMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAQEAcZUS6VGHVmnN
# 793afKpjerN4zwY3QITvS4S/ys8DAv3Fp8MOIEIsr3fzKx8MIVoqtwU0HWqumfgn
# oma/Capg33akOpMP+LLR2HwZYuhegiUexLoceywh4tZbLBQ1QwRostt1AuByx5jW
# PGTlH0gQGF+JOGFNYkYkh2OMkVIsrymJ5Xgf1gsUpYDXEkdws3XVk4WTfraSZ/tT
# YYmo9WuWwPRYaQ18yAGxuSh1t5ljhSKMYcp5lH5Z/IwP42+1ASa2bKXuh1Eh5Fhg
# m7oMLSttosR+u8QlK0cCCHxJrhO24XxCQijGGFbPQTS2Zl22dHv1VjMiLyI2skui
# SpXY9aaOUjCCBV8wggRHoAMCAQICEA4aVDLdpLG7OH34R2Dbh3owDQYJKoZIhvcN
# AQELBQAwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBB
# c3N1cmVkIElEIENvZGUgU2lnbmluZyBDQTAeFw0yMTA1MDMwMDAwMDBaFw0yMzA1
# MDgyMzU5NTlaMIGcMQswCQYDVQQGEwJVUzEQMA4GA1UECBMHRmxvcmlkYTEYMBYG
# A1UEBxMPRm9ydCBMYXVkZXJkYWxlMR0wGwYDVQQKExRDaXRyaXggU3lzdGVtcywg
# SW5jLjEjMCEGA1UECxMaWGVuQXBwKFNlcnZlciBTSEEyNTYpIDIwMjExHTAbBgNV
# BAMTFENpdHJpeCBTeXN0ZW1zLCBJbmMuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
# MIIBCgKCAQEAuavTL6Yet5dIADaHnZ2vEr5llupj1U8PMiNel5K/b1iu5UvrqZU/
# NmVPG/YVtOA0lYrH9yggaLB8BEWjyECU4FwT+V5fgLk5r51mYEAn/R0dVzRGqnPm
# eIAy5vXRMYEr3xbHOEZ7H26fmAOU8OS7Y7stS7sD/58LlfhAhYSZvdWQbHDHElC1
# iLwDpf6V/jaZByVAQ0N30DLUUJqrgXGVc9pyJlGoo+LBjBoApRK0lVDA5KyeRjfE
# N0OW+QGq/kDzjqEhzdeIaHInFbTAAyRJUP7SwkiutuaujsqVDOkfrrmYSiJRsGCq
# mKhFRywFiMVe7UTdixfyKX1peI1LVBVQ2wIDAQABo4IBxDCCAcAwHwYDVR0jBBgw
# FoAUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHQYDVR0OBBYEFDaiqfd63ahTbcfDli1B
# ojDIYVXGMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzB3BgNV
# HR8EcDBuMDWgM6Axhi9odHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hhMi1hc3N1
# cmVkLWNzLWcxLmNybDA1oDOgMYYvaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL3No
# YTItYXNzdXJlZC1jcy1nMS5jcmwwSwYDVR0gBEQwQjA2BglghkgBhv1sAwEwKTAn
# BggrBgEFBQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAgGBmeBDAEE
# ATCBhAYIKwYBBQUHAQEEeDB2MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wTgYIKwYBBQUHMAKGQmh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydFNIQTJBc3N1cmVkSURDb2RlU2lnbmluZ0NBLmNydDAMBgNVHRMB
# Af8EAjAAMA0GCSqGSIb3DQEBCwUAA4IBAQCJYN/TJLCv74Z0eXeNdbizjbpX+WEN
# VltdICN6DjRCmjqkOaMVLaKw9FGS9JwwIIuE5LDHjge9BGZ/vwpbEtcNtArm6vqm
# 69KkoDXKGgY4HH1AACUEOrT+cq7fR4fcxd8ur1HuI4OE5yvEJAXnrNrdSCAVBB6t
# /9xxmc5UfIQme/kD4COH01+CYHliBDeQiBX6bZ+pVacpdFULXNNdqwbHtN0OSWHM
# +NXG/5jIxRRWiy4sPS0CB4UpjHBR1+mQ5bji7tE9G7Zvqjg3j7iDufJle1yEc7CJ
# 8qCj3yXfdAEE0QZoeDpwF7/owbp8mkP50OKTrITxN/SGN7988fpbtfDdMYIFdjCC
# BXICAQEwgYYwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZ
# MBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hB
# MiBBc3N1cmVkIElEIENvZGUgU2lnbmluZyBDQQIQDhpUMt2ksbs4ffhHYNuHejAJ
# BgUrDgMCGgUAoIHEMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQB
# gjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBTVbrHWKne7jjsO
# oJZxZlnULsytcTBkBgorBgEEAYI3AgEMMVYwVKA4gDYAQwBpAHQAcgBpAHgAIABT
# AHUAcABwAG8AcgB0AGEAYgBpAGwAaQB0AHkAIABUAG8AbwBsAHOhGIAWaHR0cDov
# L3d3dy5jaXRyaXguY29tIDANBgkqhkiG9w0BAQEFAASCAQBABp5ghe6IVVdPVVtE
# ENp4KMoS0M10BBy8NM9DrbaDYw9ASnq+cQkFALWbWTubhYqR6QgW90UIRpXKu1q4
# XvmnpviXxSY0MHz4CoW02PfYbWGXUpyraAvMP0lbB9JaYKmrEYOvff1Cw7ohLvUe
# ya6XY68gapY6EeKGorxsb0ae9AEhuXRq4rcSr8izS5/PXdBRiVFACxX67loIBII8
# hy34YMGqzIb/t41BZeyMLCWImsBzNd5yVumD2zS6yZLm9N9ywYzWr2ktwI9veLZI
# 22kNi2r3YZ2bq1g/fTYeBOvtPnwdfc07JYlCXY9qbIkPPNxMW1EyFnGNnJEddXLH
# 5qZ7oYIC/TCCAvkGCSqGSIb3DQEJBjGCAuowggLmAgEBMIGGMHIxCzAJBgNVBAYT
# AlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2Vy
# dC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3Rh
# bXBpbmcgQ0ECEAqSXSRVgDYm4YegBXCaJZAwDQYJYIZIAWUDBAIBBQCgggE0MBgG
# CSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTIxMTAxOTA1
# MTQ1MFowLwYJKoZIhvcNAQkEMSIEIIpY1JGE5uFaxeA08vq1o1vzUc47klBD9G9Y
# vSF4uEGwMIHIBgsqhkiG9w0BCRACLzGBuDCBtTCBsjCBrwQgsCrO26Gy12Ws1unF
# BnpWG9FU4YUyDBzPXmMmtqVvLqMwgYowdqR0MHIxCzAJBgNVBAYTAlVTMRUwEwYD
# VQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAv
# BgNVBAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0EC
# EAqSXSRVgDYm4YegBXCaJZAwDQYJKoZIhvcNAQEBBQAEggEAOula2bkwHIg4fwtf
# C+1yokORFUPVEAnJAdCW83slNng3PAmamEyofBScxQ/d82vU7TZIYGQrnX67Uh11
# LOeXc8Z+WDazQBkUQnYwpjXLtMuGAQEyEH3eTwStd3x7N1xdK2W+H0VH7jWu6Gpy
# xd51fAmmDHXj55mqWY9e9NXFx/zOnYYPTSvVvoFMdF9bsd5iiZw57g40TzwZRA3+
# n3Sjk5haIMBm0wWszi8pA2HdyP2aafVP0ly0FTYbaoXct7g1oAYBCwL/k8lqlGot
# TZdRvEPgYdZC06V9BlR14/RW4Vn5teeMnk2BSbITF4e9h0obEVTRDrnFSAgyvG/C
# WmTxlQ==
# SIG # End signature block
