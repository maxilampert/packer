﻿# Get-WindowsOptionalFeature is quite slow. Instead of constantly running it, we are using cache to store the current packages in memory. Cache can be invalidated by changing the value of CTXOEFeatures_IsCacheValid to false, in which case it will be automatically reloaded. 
# Cache is NOT inialized when module is loaded. This prevents issues in environments where all modules are loaded at launch (PowerShell v2) and this module is not supported. In such environments, module is initialized, but unsupported cmdlet is never executed.
[Array]$CTXOEFeatures_Cache = @();
$CTXOEFeatures_IsCacheValid = $False;

Function Get-CTXOEFeatures {
    If ($CTXOEFeatures_IsCacheValid -eq $false) {
        $CTXOEFeatures_Cache = Get-WindowsOptionalFeature -Online
    }

    Return $CTXOEFeatures_Cache
}
Function Test-CTXOEFeaturesState ([String]$Name, [String]$State) {
    [Hashtable]$Return = @{}
    $Return.Result = $False; 

    # First test if feature even exists on this machine
    $m_RequestedFeature = $(Get-CTXOEFeatures | Where-Object {$_.FeatureName -eq $Name});

    # If not found, abort execution
    If ($m_RequestedFeature -isnot [Object]) {
        $Return.Details = "Feature $($Name) was not found on this machine";
        $Return.NotFound = $true;
        Return $Return;
    }

    # Check the state of feature
    $Return.LastState = $m_RequestedFeature.State;
    $Return.Result = $m_RequestedFeature.State -eq $State;
    
    # Supported values for requested state is Enable/Disable. However, State has different variations of this (e.g. DisablePending).
    # We are checking if current state begins with requested state.
    If ($m_RequestedFeature.State -like "$State*") {
        $Return.Result = $True;
        $Return.Details = "Feature $Name is set to $State";
    } Else {
        $Return.Details = "Feature $Name should be in state $State, but is $($m_RequestedFeature.State)";
    }

    Return $Return
}

Function Invoke-CTXOEFeaturesExecuteInternal ([Xml.XmlElement]$Params, [Boolean]$RollbackSupported = $False) {
    [Hashtable]$m_Result = Test-CTXOEFeaturesState -Name $Params.Name -State $Params.Value

    # If feature is already configured, no action need to be taken.
    If ($m_Result.Result -eq $true) {
        $Global:CTXOE_Result = $m_Result.Result;
        $Global:CTXOE_Details = $m_Result.Details;
        Return;
    }

    # If feature was not found, return
    If ($m_Result.NotFound) {
        # If feature should be disabled AND does not exists, that's OK. But if other value was configured than DISABLED, it's not OK. 
        $Global:CTXOE_Result = $Params.Value -eq "Disabled"
        $Global:CTXOE_Details = "Feature $($Params.Name) was not found on this machine"
        Return
    }

    # Invalidate cache
    $CTXOEFeatures_IsCacheValid = $False;

    # Set feature to requested state
    Try {
        If ($Params.Value -eq "Disable") {
            Disable-WindowsOptionalFeature -FeatureName $Params.Name -Online -NoRestart | Out-Null;
        } ElseIf ($Params.Value -eq "Enable") {
            Enable-WindowsOptionalFeature -FeatureName $Params.Name -Online -NoRestart | Out-Null;
        } Else {
            Throw "Unsupported value $($Params.Value) requested for feature $($Params.Name)";
        }
    } Catch {
        $Global:CTXOE_Result = $False; 
        $Global:CTXOE_Details = "Failed to change feature $($Params.Name) to state $($Params.State) with following error: $($_.Exception.Message)"; 
        Return
    }

    # Same the last known startup type for rollback instructions
    $Global:CTXOE_SystemChanged = $true;
    If ($RollbackSupported) {
        [Xml.XmlDocument]$m_RollbackElement = CTXOE\ConvertTo-CTXOERollbackElement -Element $Params

        # Rollback has to be hardcoded. This is required to prevent states like "EnablePending" from being saved. The only two supported states should be "Enable" and "Disable"
        If ($m_Result.LastState -like "Enable*") {
            $m_RollbackElement.rollbackparams.value = "Enable";
        } ElseIf ($m_Result.LastState -like "Disable*") {
            $m_RollbackElement.rollbackparams.value = "Disable";
        }
        $Global:CTXOE_ChangeRollbackParams = $m_RollbackElement
    }

    [Hashtable]$m_Result = Test-CTXOEFeaturesState -Name $Params.Name -State $Params.Value
    $Global:CTXOE_Result = $m_Result.Result
    $Global:CTXOE_Details = $m_Result.Details
    

    Return
}

Function Invoke-CTXOEFeaturesAnalyze ([Xml.XmlElement]$Params) {
    [Hashtable]$m_Result = Test-CTXOEFeaturesState -Name $Params.Name -State $Params.Value

    $Global:CTXOE_Result = $m_Result.Result
    $Global:CTXOE_Details = $m_Result.Details

    Return

}

Function Invoke-CTXOEFeaturesExecute ([Xml.XmlElement]$Params) {
    Invoke-CTXOEFeaturesExecuteInternal -Params $Params -RollbackSupported $True
}

Function Invoke-CTXOEFeaturesRollback ([Xml.XmlElement]$Params) {
    Invoke-CTXOEFeaturesExecuteInternal -Params $Params -RollbackSupported $False
}
# SIG # Begin signature block
# MIIa/AYJKoZIhvcNAQcCoIIa7TCCGukCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUufszzxc3vxqWtwI3kCHhkqEC
# ZHagghTwMIIFJDCCBAygAwIBAgIQCpJdJFWANibhh6AFcJolkDANBgkqhkiG9w0B
# AQsFADByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFz
# c3VyZWQgSUQgVGltZXN0YW1waW5nIENBMB4XDTE4MDgwMTAwMDAwMFoXDTIzMDkw
# MTAwMDAwMFowYDELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFENpdHJpeCBTeXN0ZW1z
# LCBJbmMuMQ0wCwYDVQQLEwRHTElTMSMwIQYDVQQDExpDaXRyaXggVGltZXN0YW1w
# IFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANjWtJ4e
# cpVfB34YnxfYNvb1Rp2JbBu5/G9Boe8aEBQc2zidW82ousZrXj2QD2qUA1Ee8noo
# t1KGcQdY0WzzbSIU7KHePB5KaESWjtHVJ3BW6W9q+U24m2dPD/oaNxGx6DtD7M0N
# lMBIRZKo7aNIsRIlHkg7wnNQzqi0jTkzBO7S34holaqhfuQgqkgKqGmcoSIXVqNm
# EFaU+5kpYFqpMo6x1sSAgfgNEcIgGjnj8xzdU1rnh6iNYMxOt8guMWk2z+KKNbux
# H6YLAA9VBYW417Zf153/5L4ejuxxUhCp03JkoUIWjSRjz3m24HD9K8NSgJ0AdDpN
# E8ZPmIJCMFi9FYcCAwEAAaOCAcYwggHCMB8GA1UdIwQYMBaAFPS24SAd/imu0uRh
# pbKiJbLIFzVuMB0GA1UdDgQWBBS1Y37AhXUHPaYuvS/SUsWFFisSbTAMBgNVHRMB
# Af8EAjAAMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDBP
# BgNVHSAESDBGMDcGCWCGSAGG/WwHATAqMCgGCCsGAQUFBwIBFhxodHRwczovL3d3
# dy5kaWdpY2VydC5jb20vQ1BTMAsGCWCGSAGG/WwDFTBxBgNVHR8EajBoMDKgMKAu
# hixodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVkLXRzLmNybDAy
# oDCgLoYsaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC10cy5j
# cmwwgYUGCCsGAQUFBwEBBHkwdzAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tME8GCCsGAQUFBzAChkNodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRTSEEyQXNzdXJlZElEVGltZXN0YW1waW5nQ0EuY3J0MA0GCSqG
# SIb3DQEBCwUAA4IBAQBrQ4tHgdu37madmYML6Ikfb8bNWoritioGcrlVfsMEGdLN
# LAsPYqrMo9mZmNzKTE7UVzGVdwb+Cfz9IRfD6hmK6hhEuom+XNzC8LGQ3o7U2ede
# YF/xuIcFZAwmQnXOoVl4yDWKrfyalOIO9wpQ6bDV7f0CPa8j3Qj2eNJ2u2qKnRE+
# x5Iz8j5lsjQeefIriGVHd27R93ai0li9WZMT9KKOAk06R0Z0qyG70jXhoUp4Or5c
# lv5mmVJgmxr1hMjVg7v95WGY50p2+cfhqLlViu2cu0LCg31IUb0lbTYNbgY1eca2
# cr8F0ppVnrt55YVfb1M80huj9DeYYjeFSKkcN+6xMIIFMDCCBBigAwIBAgIQBAkY
# G1/Vu2Z1U0O1b5VQCDANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMG
# A1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQw
# IgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMTMxMDIyMTIw
# MDAwWhcNMjgxMDIyMTIwMDAwWjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhE
# aWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ29kZSBTaWduaW5nIENBMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+NOzHH8OEa9ndwfTCzFJGc/Q+0WZsTrb
# RPV/5aid2zLXcep2nQUut4/6kkPApfmJ1DcZ17aq8JyGpdglrA55KDp+6dFn08b7
# KSfH03sjlOSRI5aQd4L5oYQjZhJUM1B0sSgmuyRpwsJS8hRniolF1C2ho+mILCCV
# rhxKhwjfDPXiTWAYvqrEsq5wMWYzcT6scKKrzn/pfMuSoeU7MRzP6vIK5Fe7SrXp
# dOYr/mzLfnQ5Ng2Q7+S1TqSp6moKq4TzrGdOtcT3jNEgJSPrCGQ+UpbB8g8S9MWO
# D8Gi6CxR93O8vYWxYoNzQYIH5DiLanMg0A9kczyen6Yzqf0Z3yWT0QIDAQABo4IB
# zTCCAckwEgYDVR0TAQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0l
# BAwwCgYIKwYBBQUHAwMweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRw
# Oi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRz
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwgYEGA1Ud
# HwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFz
# c3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwTwYDVR0gBEgwRjA4BgpghkgB
# hv1sAAIEMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9D
# UFMwCgYIYIZIAYb9bAMwHQYDVR0OBBYEFFrEuXsqCqOl6nEDwGD5LfZldQ5YMB8G
# A1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMA0GCSqGSIb3DQEBCwUAA4IB
# AQA+7A1aJLPzItEVyCx8JSl2qB1dHC06GsTvMGHXfgtg/cM9D8Svi/3vKt8gVTew
# 4fbRknUPUbRupY5a4l4kgU4QpO4/cY5jDhNLrddfRHnzNhQGivecRk5c/5CxGwcO
# kRX7uq+1UcKNJK4kxscnKqEpKBo6cSgCPC6Ro8AlEeKcFEehemhor5unXCBc2XGx
# DI+7qPjFEmifz0DLQESlE/DmZAwlCEIysjaKJAL+L3J+HNdJRZboWR3p+nRka7Lr
# ZkPas7CM1ekN3fYBIM6ZMWM9CBoYs4GbT8aTEAb8B4H6i9r5gkn3Ym6hU/oSlBiF
# LpKR6mhsRDKyZqHnGKSaZFHvMIIFMTCCBBmgAwIBAgIQCqEl1tYyG35B5AXaNpfC
# FTANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNl
# cnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdp
# Q2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMTYwMTA3MTIwMDAwWhcNMzEwMTA3
# MTIwMDAwWjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkw
# FwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEy
# IEFzc3VyZWQgSUQgVGltZXN0YW1waW5nIENBMIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEAvdAy7kvNj3/dqbqCmcU5VChXtiNKxA4HRTNREH3Q+X1NaH7n
# tqD0jbOI5Je/YyGQmL8TvFfTw+F+CNZqFAA49y4eO+7MpvYyWf5fZT/gm+vjRkcG
# GlV+Cyd+wKL1oODeIj8O/36V+/OjuiI+GKwR5PCZA207hXwJ0+5dyJoLVOOoCXFr
# 4M8iEA91z3FyTgqt30A6XLdR4aF5FMZNJCMwXbzsPGBqrC8HzP3w6kfZiFBe/WZu
# VmEnKYmEUeaC50ZQ/ZQqLKfkdT66mA+Ef58xFNat1fJky3seBdCEGXIX8RcG7z3N
# 1k3vBkL9olMqT4UdxB08r8/arBD13ays6Vb/kwIDAQABo4IBzjCCAcowHQYDVR0O
# BBYEFPS24SAd/imu0uRhpbKiJbLIFzVuMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1R
# i6enIZ3zbcgPMBIGA1UdEwEB/wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMIMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MIGB
# BgNVHR8EejB4MDqgOKA2hjRodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNl
# cnRBc3N1cmVkSURSb290Q0EuY3JsMDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMFAGA1UdIARJMEcwOAYK
# YIZIAYb9bAACBDAqMCgGCCsGAQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5j
# b20vQ1BTMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAQEAcZUS6VGHVmnN
# 793afKpjerN4zwY3QITvS4S/ys8DAv3Fp8MOIEIsr3fzKx8MIVoqtwU0HWqumfgn
# oma/Capg33akOpMP+LLR2HwZYuhegiUexLoceywh4tZbLBQ1QwRostt1AuByx5jW
# PGTlH0gQGF+JOGFNYkYkh2OMkVIsrymJ5Xgf1gsUpYDXEkdws3XVk4WTfraSZ/tT
# YYmo9WuWwPRYaQ18yAGxuSh1t5ljhSKMYcp5lH5Z/IwP42+1ASa2bKXuh1Eh5Fhg
# m7oMLSttosR+u8QlK0cCCHxJrhO24XxCQijGGFbPQTS2Zl22dHv1VjMiLyI2skui
# SpXY9aaOUjCCBVswggRDoAMCAQICEAnDseogl67R4kPZAkwTwVowDQYJKoZIhvcN
# AQELBQAwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBB
# c3N1cmVkIElEIENvZGUgU2lnbmluZyBDQTAeFw0yMDA2MTgwMDAwMDBaFw0yMTA2
# MjMxMjAwMDBaMIGXMQswCQYDVQQGEwJVUzEQMA4GA1UECBMHRmxvcmlkYTEYMBYG
# A1UEBxMPRm9ydCBMYXVkZXJkYWxlMR0wGwYDVQQKExRDaXRyaXggU3lzdGVtcywg
# SW5jLjEeMBwGA1UECxMVWGVuQXBwKFNlcnZlciBTSEEyNTYpMR0wGwYDVQQDExRD
# aXRyaXggU3lzdGVtcywgSW5jLjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAKz/6enTDjtRARofX6CxBvXTSrNSToniGVJQq0tJmtGIjuf5CKHWaGei1OGe
# kftP8Pj4Y5bGzW3sT6GwQ894B0niwu/nnqdh6VDbMWfy8eZADi4x0qYvVD7Wxmq/
# p+qAn58iRG2ikLViEUskmc2Ysa9cD8s11gCR3rLWm55zllxBbg756aJVrSRKpIcf
# Tcxm6hECowr983Np/XhVRASj47DWjBrYMeXQrtE370RhcHRStHhKhPhzcGfDKoxQ
# sT8jibnS/WYoUjO7XRsUkuQdUfgWI6FMuvfZ368mVk7SaOJx1F2LF9wec2j5dvoi
# ynLT6HGS0AhiqkiWEPLBfK1JgIUCAwEAAaOCAcUwggHBMB8GA1UdIwQYMBaAFFrE
# uXsqCqOl6nEDwGD5LfZldQ5YMB0GA1UdDgQWBBS8TYAcxKWVVRP7XZD6m2dVIFa4
# +zAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwdwYDVR0fBHAw
# bjA1oDOgMYYvaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC1j
# cy1nMS5jcmwwNaAzoDGGL2h0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9zaGEyLWFz
# c3VyZWQtY3MtZzEuY3JsMEwGA1UdIARFMEMwNwYJYIZIAYb9bAMBMCowKAYIKwYB
# BQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCAYGZ4EMAQQBMIGE
# BggrBgEFBQcBAQR4MHYwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0
# LmNvbTBOBggrBgEFBQcwAoZCaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0U0hBMkFzc3VyZWRJRENvZGVTaWduaW5nQ0EuY3J0MAwGA1UdEwEB/wQC
# MAAwDQYJKoZIhvcNAQELBQADggEBAFyJ77tCmlj1AP+NVBvr23SJfIIcp5of8Z/4
# LcYV7b2exZxLbpzrqCVUpnYW/eg4aXI1Xz3cFXWeejPaif+ZdTA2Nv8AChDuXvTF
# MUpUyNDRyv74zM267r3I8KPq+fz8kcsEncRElqRMA2HrlCJO0hG/wSMOSZHsrcEv
# DWRDmuIDnvxXXvrR+f2rq97u8Pd/iK3GKL6whMMQyXxIaQnucIezUqCZqbhggxhg
# wVkDxsYimV9IsycT4D/4WIO2J71y1ZglyUFkVMr420UpU9sdkgQixREhOJKiC0hi
# rPEZBLxqnnFUCpAzzYQTdeZc4aOixwOTgvYQn1Br+Yd5tzB5JEcxggV2MIIFcgIB
# ATCBhjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFz
# c3VyZWQgSUQgQ29kZSBTaWduaW5nIENBAhAJw7HqIJeu0eJD2QJME8FaMAkGBSsO
# AwIaBQCggcQwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFKWrYb5EFvTJ8oCLinTz
# Y0HOL6T8MGQGCisGAQQBgjcCAQwxVjBUoDiANgBDAGkAdAByAGkAeAAgAFMAdQBw
# AHAAbwByAHQAYQBiAGkAbABpAHQAeQAgAFQAbwBvAGwAc6EYgBZodHRwOi8vd3d3
# LmNpdHJpeC5jb20gMA0GCSqGSIb3DQEBAQUABIIBAIQhDD5wDTwGYLC9nKRm2Zki
# i3VhjXCdNsbH8hSc+mBd/ay6TgSDovhOAE3TBjAOymVF7mlsERCnAOc0VSqOC1SF
# sCiVEECjL2+SoersnUVetcctITapTHkv6EQ6PxUBcUAjnV+mmqUWgC8aa/13rP+G
# QQsg7i+0j74bR8o6k0A+YnprCqSYrsXWEIIX+m0h9S/TZx2QKDy6OndjnyulCaTm
# Rt7B0Qmmva/aWNeQ8vMq9Dh/zH0EGoaBtIllfenhxdZLElgw4ALK5J7gQ57CYb0p
# 3PTGMSWx5+PBVgqag7Yw1pVtnT0i4YkGfGhx5x0iiJ1BiNqf+3pSX8/ltqHYz52h
# ggL9MIIC+QYJKoZIhvcNAQkGMYIC6jCCAuYCAQEwgYYwcjELMAkGA1UEBhMCVVMx
# FTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNv
# bTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIFRpbWVzdGFtcGlu
# ZyBDQQIQCpJdJFWANibhh6AFcJolkDANBglghkgBZQMEAgEFAKCCATQwGAYJKoZI
# hvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjEwMjA1MDkxMjQw
# WjAvBgkqhkiG9w0BCQQxIgQg+B8blx7IffgVWBGoAy65SbiJwIIhB2mGSNqv4PjD
# fVMwgcgGCyqGSIb3DQEJEAIvMYG4MIG1MIGyMIGvBCCwKs7bobLXZazW6cUGelYb
# 0VThhTIMHM9eYya2pW8uozCBijB2pHQwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoT
# DERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UE
# AxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIFRpbWVzdGFtcGluZyBDQQIQCpJd
# JFWANibhh6AFcJolkDANBgkqhkiG9w0BAQEFAASCAQCE8awNPVdNPKRM4HOM+9F8
# j1Gr8rjKQ7Q6tLaKPyz53BbbjgMaMlkC0P0h/QrevBKcMLRXKGzp7brVGHvx4tmO
# OiSmgIN8iIzw2TPYG+ohXcuIkRU8tVkH5MMIpsUZHM7A7m/PQ9BUgAvCyIqejcVz
# F5M9aQhbVvemWHPfYnnGCou1/t7S7cBwFQnttw2pUxSaai+icZRuG1kyv0RIG/+Z
# YDDyDdFq3ZloOa/f332dgMuyepL84EJAj8VoekfYPymDJ065hFAzPC8GTdeSsbku
# QqMTorTcbHJ8sML8OovZs2TR+qSBETjRPvB0YwbrOTVXpNem3f4go75iwn0JL3bb
# SIG # End signature block
